package com.devsuperior.dsMeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsMetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsMetaApplication.class, args);
	}

}
