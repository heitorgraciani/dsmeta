package com.devsuperior.dsMeta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsMetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
